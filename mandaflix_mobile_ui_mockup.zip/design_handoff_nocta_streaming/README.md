# Handoff: Mandaflix — recommender streaming frontend

## Overview

A streaming-service style frontend for the `mandacode/ai-movie-recommender` project (MovieLens `ml-latest-small`). It lets you switch between user profiles and see how the recommendation list changes, browse a personalised tile grid, search the catalogue, and open a movie detail page. No algorithm internals (scores, "why this?", neighbours) are exposed — that was an explicit product decision.

## About the design files

`Aureo.dc.html` in this bundle is a **design reference written in HTML** — a prototype showing intended look and behaviour, not production code to copy. Recreate it in the target codebase using that codebase's own environment and patterns (React + your component library, Next.js, Vue, etc.). If the project has no frontend yet, pick the framework that fits the Python backend best (a React/Next.js SPA against a FastAPI endpoint is the obvious pairing) and implement the designs there.

The prototype's data (24 movies, 8 users, genre-affinity ranking) is a hard-coded stand-in. In the real build, all of it comes from the backend: the ranked list must come from the fitted recommender (`src/recommenders/*`), not from a client-side score.

## Fidelity

**High-fidelity.** Colors, typography, spacing, radii and interaction states are final and taken from the Nocturne design system (`nocturne-styles.css`, `nocturne-readme.md` in this bundle). Recreate the UI to match. The only placeholders are imagery: posters and backdrops are striped CSS placeholders where TMDB key art should go (`scripts/fetch_tmdb.py` already fetches the ids).

## Screens / views

### 1. App shell / header (persistent)

Sticky, `z-index` above content, height ~59px: `padding: 14px 32px`, background `linear-gradient(180deg, rgba(22,24,38,.97), rgba(22,24,38,.86))` with `backdrop-filter: blur(10px)`, bottom border `1px solid rgba(233,233,237,.08)`. One flex row, `gap: 22.4px`, items centered:

- **Logo** — wordmark only, "MANDAFLIX" at 18px, weight 600, uppercase, `letter-spacing: .16em`, color `var(--color-accent)`. It is a button → home. No letter mark, no filled square.
- **Nav** — "Home", "My list". 13px, `#b2b6ca`, hover `#e9e9ed`, `gap: 16.8px`.
- **Spacer** (`flex: 1`).
- **Search field** — 34px tall, `min-width: 230px`, `padding: 0 11.2px`, `1px solid #3f424d`, radius 8px, background `rgba(35,37,50,.6)`; Phosphor `ph-magnifying-glass` 15px `#9397ab` + input 13px, transparent background, no outline. Border turns accent on focus-within. Placeholder: "Search titles, genres, people".
- **Profile switcher** — two variants, see below.

### 2. Profile switcher (two variants — pick one)

**Chips (variant A):** horizontal scrolling row of 8 avatar buttons, 30×30px, radius 8px, initials at 11px/600. Inactive: `1px solid #3f424d`, transparent, text `#9397ab`. Active: `1px solid var(--acc)`, background `color-mix(in srgb, var(--acc) 20%, transparent)`, text accent. `title` attribute = "Ava Renn — user #414 · 2,698 ratings".

**Panel (variant B, currently chosen):** trigger button 34px tall, `padding: 0 8.4px 0 5.6px`, `1px solid #3f424d`, radius 8px, background `rgba(35,37,50,.6)`, containing a 24×24 accent-tinted avatar (radius 6px), the user name at 12.5px `#cfd3e5`, and `ph-caret-down` 12px. Hover: border `color-mix(in srgb, var(--acc) 55%, transparent)`. Click opens a dropdown, absolutely positioned `right: 0; top: 42px`, width 300px, `padding: 8.4px`, background `#232532`, radius 14px, shadow `0 0 0 1px #595d6c, 0 6px 18px rgba(0,0,0,.55)`. Inside: an uppercase 10.5px `.12em` label "Switch profile" in `#9397ab`, then 8 rows (`gap: 11.2px`, `padding: 7px 8.4px`, radius 8px) each with a 28×28 avatar, the name at 13px and `user #414 · 2,698 ratings` at 11px `#9397ab`. Selected row: background `color-mix(in srgb, var(--acc) 12%, transparent)`, avatar tinted 22% accent with accent text; unselected avatar `#292b31` on `#9397ab`.

Switching a profile resets to home, clears the search query, closes the panel, and re-ranks every row.

### 3. Home

**Hero band** — full-bleed, Netflix-style: `min-height: 660px`, `padding: 56px 32px`, `align-items: flex-end`, `overflow: hidden`, content in a `position: relative` column of `max-width: 600px`. Stacked absolute layers, bottom to top: (1) the backdrop still filling the band (`background-size: cover; background-position: center 30%`; in the prototype a striped placeholder sits under it and a `--hero-img` URL variable paints over it), (2) a left-to-right scrim `linear-gradient(90deg,#161826 0%, rgba(22,24,38,.88) 34%, rgba(22,24,38,.25) 68%, rgba(22,24,38,.45) 100%)`, (3) a 240px bottom fade `linear-gradient(0deg,#161826 6%, rgba(22,24,38,0) 100%)` so the band dissolves into the page. There is no side poster. In production the still is the hero title's TMDB backdrop and changes with the profile.

Text column, `max-width: 600px`, `gap: 16.8px`:
- Kicker: "Top pick for {user name}" — 10.5px, `letter-spacing: .16em`, uppercase, accent.
- Title: `h1`, 52px, `line-height: 1.02`, weight 500, `letter-spacing: -.02em`, `text-wrap: pretty`.
- Meta row: year · runtime (`2h 34m`) · genres, 12.5px `#b2b6ca`, separators `·` in `#595d6c`, `gap: 11.2px`.
- Synopsis: 14.5px/1.6, `#cfd3e5`, `max-width: 480px`.
- Buttons, `gap: 11.2px`, both 40px tall, `padding: 0 18px`, radius 8px, transparent fill (Nocturne outlines primaries, never fills them): **Play** = `1px solid var(--acc)`, accent text, `ph-play`, hover background `color-mix(in srgb, var(--acc) 14%, transparent)`. **More info** = `1px solid #595d6c`, `#cfd3e5`, `ph-info`, hover border `#9397ab` / text `#e9e9ed`.

The band carries a monospace 10px "backdrop still — full bleed" caption top-right; drop it once real imagery lands.

**Genre chips** — scrolling row, `gap: 5.6px`, above the rows. Each 29px tall, `padding: 0 14px`, `border-radius: 999px`, 12px. Inactive `1px solid #3f424d` / `#b2b6ca`; active `1px solid var(--acc)`, background 16% accent tint, accent text. First chip "All"; the rest are the catalogue's genres, alphabetical. Filters the "For you" row.

**Row: For you** — heading 17px/500 with a 11.5px `#9397ab` sub-note ("ranked for Ava Renn" or "Sci-Fi · ranked for Ava Renn"). Horizontal scroller, `gap: 14px`. Tiles are 186px wide, `aspect-ratio: 2/3` (or 296px / `16/9` in the Wide variant), radius 8px, `box-shadow: 0 0 0 1px #3f424d`. Hover: `translateY(-3px)` and `box-shadow: 0 0 0 1px var(--acc), 0 8px 24px rgba(0,0,0,.5)`. Rank badge top-left: min 19px wide, 19px tall, radius 5px, `rgba(22,24,38,.75)`, accent text 10.5px/600. Under the tile: title 12.5px/1.3 `#e9e9ed`, then `1994 · Crime` at 11px `#9397ab`.

**Row: More for you** — same tiles, ranks 11–20, no badge.

Custom scrollbars: 6px tall, thumb `#3f424d`, radius 4px, transparent track.

### 4. Search results

Replaces the home body as soon as the query is non-empty; clearing it returns home. Heading "Results" at 20px/500 with `12 of 24 titles match “fincher”` at 12px `#9397ab`. Grid: `repeat(auto-fill, minmax(168px, 1fr))`, `gap: 18px`, same tile treatment (no rank badge, no hover lift). Prototype matches substring across title, genres, director and cast — in production this is the backend search (`src/tools.py`, optionally `src/semantic.py` for embeddings).

### 5. Movie detail

- **Backdrop band** — `min-height: 360px`, `padding: 28px 32px`, same layered background but with a bottom-up scrim `linear-gradient(0deg,#161826 4%, rgba(22,24,38,.45) 70%)`. Contains a **Back** button (32px tall, `padding: 0 11.2px`, `1px solid #3f424d`, radius 8px, `rgba(22,24,38,.6)`, `ph-arrow-left`) and a monospace "backdrop still" caption bottom-right.
- **Body** — grid `260px minmax(0,1fr)`, `gap: 44.8px`, `margin-top: -120px` so the poster overlaps the backdrop. Poster: `aspect-ratio: 2/3`, radius 14px, shadow-md. Text column has `padding-top: 126px` to sit below the overlap.
- Title `h1` 40px/1.05, weight 500, `-.02em`. Meta row as in the hero.
- Action row: **Play** (38px, accent outline, `ph-play`) plus two 38×38 icon buttons (`ph-plus`, `ph-thumbs-up`) with `1px solid #595d6c`, hover border+icon accent.
- Synopsis 15px/1.65 `#cfd3e5`, `max-width: 620px`.
- Credits strip: top border `1px solid rgba(233,233,237,.1)`, `padding-top: 16.8px`, grid `repeat(auto-fit, minmax(180px,1fr))`, `gap: 22.4px`. Three fields — Director, Cast, Genres — each an uppercase 10.5px `.12em` `#9397ab` label over a 13.5px value.
- **Similar movies** row: 168px tiles, ranked by the same profile affinity, excluding the current title, sharing at least one genre, capped at 7.

### 6. Footer

`padding: 22.4px 32px 44.8px`, top border `rgba(233,233,237,.08)`, 11.5px `#9397ab`: wordmark · "Recommendations from the MovieLens ml-latest-small profile of {user name}".

## Interactions & behavior

- Logo, nav items and Back → home; home resets query and closes the panel.
- Any tile click → detail for that movie, scrolled to top.
- Search input is controlled: non-empty (after trim) switches to the results screen, empty returns home.
- Genre chip click sets the filter and returns to home.
- Profile chip/row click sets the user, returns home, clears query, closes panel.
- Panel trigger toggles the dropdown. (Production should add outside-click and `Escape` to close — the prototype does not.)
- Hover states as specified above; tile hover has a `translateY(-3px)` lift. No timed animations — transitions of ~120–160ms ease-out on transform/box-shadow/border are appropriate.
- Keyboard focus is `outline: 2px solid var(--acc); outline-offset: 2px` everywhere — never the browser default.
- No loading or error states are designed. Add them: skeleton tiles at the row's tile dimensions in `#232532` for pending recommendations, and an inline message in the row's place on failure.
- **Mobile is designed** — see the section below. The desktop layout holds above 760px.

## Mobile (≤ 760px)

The prototype implements this with a `@media (max-width:760px)` block whose declarations carry `!important` (they override the inline styles the prototype is written in). In a real codebase write these as ordinary responsive styles — do not port the `!important`.

- **Header** wraps into two rows: the wordmark on the left; a search icon button and a hamburger pushed right (both `.btn-secondary.btn-icon`, 36×36); when opened, the search field takes a full-width second row. The desktop text nav and the avatar chip strip are hidden.
- **Search** is an icon, not a field. Tapping it reveals the input and focuses it; tapping the hamburger closes it, and vice versa. The bottom bar's Search tab does the same.
- **Hamburger menu** — opens in-header (not a drawer), toggling the icon to `ph-x`: an uppercase "Switch profile" label, the eight profile rows (avatar, name, `user #414 · 2,698 ratings`), then Home and My list under a divider. Picking a profile closes the menu and returns home.
- **Bottom tab bar** — fixed, `rgba(22,24,38,.94)` + blur, top divider, 52px targets, safe-area padding: Home / Search / My list, icon over a 10.5px label; the active tab is in the accent. The page body carries 96px bottom padding to clear it.
- **Hero** — 78vh, 24px/16px padding, title 34px, body 13.5px; still full-bleed with the same scrims.
- **Rows** — tiles 138px wide (232px in the Wide variant); the tile width is set from JS on a `matchMedia` listener because it lives in a root variable.
- **Search results** — grid `minmax(104px, 1fr)`, 12px gap (three across at 390px).
- **Detail** — single column, backdrop band 200px, `margin-top: -64px`, poster 132px, title 28px, no top padding on the text column.
- Page gutters drop from 32px to 16px throughout. The monospace placeholder captions are hidden.

Deep links exist for previewing states: `#search=<query>`, `#movie=<id>`, `#user=<id>` are read once on mount.

## State management

Prototype state, all client-side:

| State | Type | Set by |
| --- | --- | --- |
| `userId` | number (MovieLens user id) | profile switcher |
| `screen` | `"home" \| "search" \| "detail"` | nav, tiles, search input |
| `movieId` | number \| null | tile clicks |
| `query` | string | search input |
| `genre` | string (`"All"` or a genre) | genre chips |
| `panelOpen` | boolean | switcher trigger (desktop) |
| `menuOpen` | boolean | hamburger (mobile) |
| `searchOpen` | boolean | search icon / Search tab (mobile) |

Derived in the prototype, **to be replaced by backend calls** in the real build:

- ranked list for the current user → `GET /recommendations?user_id=&k=&genre=` backed by the fitted recommender
- hero = rank 1 of that list
- search results → `GET /search?q=`
- similar titles → `GET /movies/{id}/similar`
- movie detail → `GET /movies/{id}`

The prototype's client-side scoring (`sum of the user's genre weights × 1000 + rating count`) exists only to make profile switching visibly change the results. Do not port it.

Fetching notes: cache per `(userId, genre)`; the ranked list changes only on profile or genre change. Debounce search ~200ms.

## Design tokens (Nocturne)

Colors — take these from `nocturne-styles.css` variables, not literals:

- `--color-bg #161826`, `--color-surface #232532`, `--color-text #e9e9ed`
- neutrals: `100 #f3f5fe`, `200 #e4e7f5`, `300 #cfd3e5`, `400 #b2b6ca`, `500 #9397ab`, `600 #75798c`, `700 #595d6c`, `800 #3f424d`, `900 #292b31`
- accent (system default) `--color-accent #9184d9`, ramp `300 #d2cefd`, `400 #b5abfc`, `500 #968ae0`, `600 #796cbf`, `700 #5d5294`, `800 #423a6a`, `900 #2b2741`
- divider `color-mix(in srgb, #e9e9ed 16%, transparent)`
- The accent is driven by one variable: the prototype sets `--color-accent` on the root and aliases `--acc` to it, so both the design-system classes (`.btn-primary`, `.tag-outline`, `.input`, `.card-kicker`) and the hand-styled chrome follow it. Options: **Violet `#9b4dff` (shipped — a neon violet matched to the Mandaflix logo)**, Magenta `#d926ef`, Amber `#F5C518`, Azure `#5aa9f2`. Ship Violet. Everything accent-tinted derives from `--acc` via `color-mix`, so one variable is the whole switch.
- Body copy must never be set in the raw accent — use `--color-accent-300` for accent-colored paragraph text (the accent/ground pair is only 3:1).

Spacing (density 0.70×): `2.8 / 5.6 / 8.4 / 11.2 / 16.8 / 22.4px`, with 32px page gutters and 44.8px / 67.2px section rhythm.

Radii: `--radius-sm 4px`, `--radius-md 8px`, `--radius-lg 14px`, plus `999px` for chips.

Shadows: `--shadow-sm 0 0 0 1px #3f424d`; `--shadow-md 0 0 0 1px #595d6c, 0 6px 18px rgba(0,0,0,.55)`; `--shadow-lg 0 0 0 1px #9397ab, 0 16px 40px rgba(0,0,0,.65)`. Do not stack shadows.

Type: Inter throughout (`--font-heading` / `--font-body`), headings at weight 500 — never heavier. Sizes used: 52 / 40 / 20 / 17 / 15 / 14.5 / 13.5 / 13 / 12.5 / 11.5 / 11 / 10.5px.

## Brand

Four name + letter-mark options were explored: **Mandaflix** — shipped — plus Aureo, Vela, Nocta, Lumen. There is no letter mark: the logo is the wordmark alone, "MANDAFLIX" at 18px, weight 600, uppercase, `letter-spacing: .16em`, set in the accent (`var(--color-accent)`). It replaced an earlier accent-filled square + initial mark. The user has a neon-sign logo treatment (magenta/violet tube lettering on black) — if you have that file, use it in place of the CSS wordmark; the interface accent was picked to match it.

## Design-system components used

The prototype links the bound Nocturne stylesheet and bundle and composes its classes — recreate against the same system, do not re-derive these:

- `.btn` + `.btn-primary` (Play, both instances), `.btn-secondary` (More info, Back), `.btn-secondary.btn-icon` (add / thumbs-up)
- `.tag` / `.tag-outline` (genre chips; outline variant = active)
- `.input` (search field, with the Phosphor icon absolutely positioned at 10px and `padding-left: 31px`)
- `.nav` + `.nav-brand` (header bar and wordmark)
- `--shadow-sm` / `--shadow-md` / `--shadow-lg` for tiles, hero poster and the profile dropdown respectively

## Assets

- **Fonts:** Inter 400/500/600 (Google Fonts).
- **Icons:** Phosphor Icons regular (`@phosphor-icons/web@2.1.1`) — `magnifying-glass`, `caret-down`, `play`, `info`, `plus`, `thumbs-up`, `arrow-left`.
- **Imagery:** none. All posters and backdrops are CSS stripe placeholders (`.poster` class in the prototype). Real key art should come from TMDB via `scripts/fetch_tmdb.py` + `datasets/ml-latest-small/links.csv`. Per Nocturne, wrap content photographs in `.lighten` and prefer stills with dark grounds.
- **Copy:** movie titles, years, runtimes, directors, casts and synopses in the prototype are real film data for 24 MovieLens titles; user names are invented, their ids and rating counts are plausible `ml-latest-small` values.

## Files

- `Mandaflix Mobile.dc.html` — three live 390×844 frames (home, search, detail) for reviewing the mobile layout.
- `Aureo.dc.html` — the full prototype (all screens, both switcher variants, both tile shapes, all four accents). The filename predates the Mandaflix name.
- `nocturne-styles.css` — the design system's only stylesheet: tokens + component layer.
- `nocturne-readme.md` — the design system's own guide, including the rules this design follows (outlined buttons, no accent floods, no pure black/white, compact spacing).
